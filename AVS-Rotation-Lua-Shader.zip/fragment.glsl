precision highp float;
uniform sampler2D u_sTexture0;
uniform highp float u_alpha;
uniform highp mat4 u_color_matrix;
uniform highp vec2 u_outputSize;
uniform highp float u_angle;
varying highp vec2 v_texCoord;
void main() {
    float r = u_angle * 0.017453292519943295;
    float c = cos(r), s = sin(r);
    vec2 size = max(u_outputSize, vec2(1.0));
    float bw = abs(size.x*c) + abs(size.y*s);
    float bh = abs(size.x*s) + abs(size.y*c);
    float scale = min(size.x/bw, size.y/bh);
    // Coordenadas de píxeles centrados: mismas fórmulas del HTML.
    vec2 pos = (v_texCoord * size - size*0.5) / scale;
    vec2 srcPixel = vec2(c*pos.x + s*pos.y, -s*pos.x + c*pos.y) + size*0.5;
    if (srcPixel.x < 0.0 || srcPixel.x >= size.x || srcPixel.y < 0.0 || srcPixel.y >= size.y) {
        gl_FragColor = vec4(0.0, 0.0, 0.0, 1.0) * u_alpha;
    } else {
        vec2 uv = (floor(srcPixel) + 0.5) / size;
        gl_FragColor = clamp(texture2D(u_sTexture0, uv) * u_color_matrix, 0.0, 1.0) * u_alpha;
    }
}
