-- AVS Rotation de Logo Editing Pro 1.1 para el motor de render de KineMaster.
-- Ángulo positivo: sentido horario; ajuste para encajar en el mismo cuadro.
function main()
    local video_src = kmInitVideoSrc()
    local width = kmGetOutputWidth()
    local height = kmGetOutputHeight()
    RotationFx.setSTexture0(system.video_left.id)
    RotationFx.setOutputSize(width, height)
    RotationFx.setAngle(range.angle * 1.0)
    RotationFx.setAlpha(effect.alpha)
    RotationFx.setColorMatrix(system.video_left.colorconv)
    RotationFx.setTexMatrix(system.video_left.texmat)
    RotationFx.setMvpMatrix(effect.matrix)
    RotationFx.drawScreen(video_src)
    kmReleaseTexture(video_src)
end
