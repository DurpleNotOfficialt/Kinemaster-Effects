	uniform sampler2D u_sTexture0;
	uniform highp float u_alpha;
	uniform highp mat4 u_color_matrix;
	uniform highp vec2 u_phase;
	uniform highp vec2  u_freq;
	uniform highp vec2  u_amp;
	uniform highp float u_angle;
	uniform highp float u_warpAngle;
	uniform highp vec2 u_wavePivot;
	uniform highp float u_bOriAlpha;
	uniform highp float u_oovAlpha; // out of view alpha
	
	uniform highp float u_dampAmp;
	uniform highp float u_dampFreq;
	uniform highp float u_dampAnch;
	
	uniform highp vec2 u_aspectRatio;
	varying highp vec2 v_v2TexCoord0;
	
	/*created by executable.*/
	
	const highp float M_PI    = 3.1415926535;
	const highp float edge2edge = 2.0; //dist from (0;0) to the edge
	
	highp vec2 getSinCos(highp float angle) {
		highp float s = sin(angle / 180.0 * 3.14);
		highp float c = cos(angle / 180.0 * 3.14);
		
		return vec2(s, c);
	}
	
	highp float getWave(highp float freq, highp float dist, highp float phase, highp float amp) {
		highp float waved;
		
		highp float wave = dist*freq + phase;
		waved = sin(wave*M_PI*2.0)*amp/2.0;
		
		return waved;
	}
	
	highp float getDamping(highp float dist, highp float val, highp float damp) {
		highp float damping;
		highp float mirrDist = (edge2edge - abs(dist))*0.5;
		
		if (damp <= 0.0)
			damping = (mirrDist*damp - damp) * val;
		else
			damping = mirrDist*damp*val;
			
		return damping;
	}
	
	highp vec2 getRotatedTex(highp vec2 p, highp float angle) {
		highp vec2 sp;
		highp vec2 sc = getSinCos(angle);
		
		sp.x = p.x*sc.x + p.y*sc.y;
		sp.y = p.x*sc.y - p.y*sc.x;
		return sp;
	}
	
	highp vec2 getWaveTex(highp vec2 st, highp vec2 freq, highp vec2 amp, highp vec2 phase, highp float angle, highp float warpAngle, highp vec2 wavePivot, highp float dampAmp, highp float dampFreq, highp float dampAnch) {
		highp vec2 waveTex = st - wavePivot / u_aspectRatio;
		highp float dist;
		
		// Apply rotation 
		waveTex = getRotatedTex(waveTex, angle);
		
		// Get sine wave values
		dist = waveTex.x;
		waveTex.x = getWave(freq.y, dist, phase.y, amp.y);
		
		dist = waveTex.y;
		highp float ampDamping = getDamping(dist, amp.x, dampAmp);
		highp float freqDamping = getDamping(dist-dampAnch*2.0, freq.x, dampFreq);
		highp float ampX = amp.x - ampDamping;
		highp float freqX = freq.x - freqDamping;
		waveTex.y = getWave(freqX, dist, phase.x, ampX);
		
		// Apply warp angle (partially taken from Wave Warp 2.0)
		highp vec2 sc = getSinCos(angle + warpAngle);
		waveTex = vec2(dot(waveTex, vec2(sc.x, sc.y)), dot(waveTex, vec2(-sc.y, sc.x)));
		
		return waveTex;
	}
	
	void main(void)
	{
	  highp vec4  color;
		highp vec2 st = v_v2TexCoord0*2.0-1.0;
		st *= u_aspectRatio;
		
		highp vec2 waveTex = getWaveTex(st,
		u_freq, u_amp, u_phase, u_angle, u_warpAngle, u_wavePivot, u_dampAmp, u_dampFreq, u_dampAnch);
		
		st += waveTex.yx;
		st /= u_aspectRatio;
		st = (st + 1.0) / 2.0;
		color = texture2D(u_sTexture0, st);
		
		if (u_bOriAlpha == 0.0)
				color.a = 1.0;
				
		// Change oov rendering (normal, empty)
		if ((st.x > 1.0 || st.x <0.0) && u_oovAlpha == 1.0)
			color *= 0.0;
		if ((st.y > 1.0 || st.y <0.0) && u_oovAlpha == 1.0)
			color *= 0.0;
		
	  color = color * u_color_matrix;
	  color = clamp(color, 0.0, 1.0);
	
	  gl_FragColor = color * u_alpha;
	
	}